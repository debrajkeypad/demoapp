<?php 
/* Admin Controller for basic operation pre and post login with added / extended methods as and when needed*/
namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\AdminModel;
use App\Models\SettingsModel;
 
class Admin extends Controller
{
    public function __construct()
    {    
        $session = session();          
        if($session->get('loggedin')==1)
        {
            return view('admin/index');
        }
        else
        {
            return view('admin/login');
        }
    }
    
    /*
    This method user log in with validation and google re captcha validation 
    */
    public function login()
    {
        if($this->request->getMethod()=="post") 
        {
        
        /* Loading security services for CSRF / Token validation to prevent any external call */    
        $security = \Config\Services::security();
            
        $session = session();          
        $session->setFlashdata('message', '');
  
        helper(['form', 'url']);
         
        $val = $this->validate([
            'username' => 'required',
            'password' => 'required'
            
        ]);
 
        $model = new AdminModel();
 
        if (!$val)
        {
 
            echo view('admin/login', [
                   'validation' => $this->validator
            ]);
 
        }
        else
        { 
            $modelSettings = new SettingsModel();
            $dataSettingsClause = array('id'=>'1');       
            $SettingsData = $modelSettings->where($dataSettingsClause);
            
            $db      = \Config\Database::connect();
            $builder = $db->table('settings');
            $query   = $builder->get();  
            $rowSettings = $query->getResult();
           
            $secret = $rowSettings[0]->recaptcha_secret_key;
            $response = trim($this->request->getVar('g-recaptcha-response'));
            $ip = $_SERVER['REMOTE_ADDR'];
            
            $dav = @file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$response."&remoteip=".$ip);
            
            $res = json_decode($dav,true);

            if($res['success']==1)
            {
           
                $data = array('username'=>$this->request->getVar('username'),'password'=>md5($this->request->getVar('password')));       
                $user =  $model->where($data); 
                $rows = $model->countAllResults();
        
                if($rows==1){
                    $loggedin = 1;
                    $session->loggedin = $loggedin;
                    return redirect()->to( base_url('admin/dashboard') );
                }else{
                    $session->setFlashdata('message', 'Invalid Username and/or Password!');
                    return view('admin/login');
                } 
           
           }
           else
           {
                $session->setFlashdata('message', 'Invalid Captcha!');
                return view('admin/login');
           }
        }
        }
        else
        {
            return redirect()->to( base_url('admin/index') );
        }
    
    }
 
    public function index()
    {    
        $session = session();          
        if($session->get('loggedin')==1)
        {
            $covid_data = $this->getdatafromapi();
            $data['covid_data'] = $covid_data;
            return view('admin/index',$data);
        }
        else
        {
           return view('admin/login');
        }
    }  
    
    public function dashboard()
    {    
        $session = session();          
        if($session->get('loggedin')==1)
        {
            $covid_data = $this->getdatafromapi();
            $data['covid_data'] = $covid_data;
            return view('admin/index',$data);
        }
        else
        {
            return redirect()->to( base_url('admin/index') );
        }
    }  
    
    /*
    This method logs out admin user
    */
    public function logout()
    {    
        $session = session();          
        $session->destroy();
        return redirect()->to( base_url('admin/index') );
    }   
 
    /*
    This method calls COVID 19 STATISTICAL DATA API and retrieve periodical data
    */
    protected function getdatafromapi()
    {    
        $options = [
        'baseURI' => 'https://corona.lmao.ninja/v2/all',
        'timeout'  => 3
];
        $client = \Config\Services::curlrequest($options);
        $response = $client->request('GET', 'https://corona.lmao.ninja/v2/all', [
                'headers' => [
                        'User-Agent' => 'testing/1.0'
                        
                ]
        ]);

        $body = $response->getBody();
        if (strpos($response->getHeader('content-type'), 'application/json') !== false)
        {
                $body = json_decode($body,true);
        }
        return $body;
    }
    
}

?>