<?php 
/* Dashboard controller for admin panel post login*/
namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\DashboardModel;
 
class Dashboard extends Controller
{
    
    public function __construct()
    {    
        $session = session();          
        if($session->get('loggedin')==1)
        {
            return view('admin/index');
        }
        else
        {
            return view('admin/login');
        }
    }  
    public function index()
    {    
        $session = session();          
        if($session->get('loggedin')==1)
        {
            $covid_data = $this->getdatafromapi();
            $data['covid_data'] = $covid_data;
            return view('admin/index',$data);
        }
        else
        {
           return view('admin/login');
        }
    }  
    
    public function logout()
    {    
        $session = session();          
        $session->destroy();
        return redirect()->to( base_url('admin/index') );
    }   
    
}

?>