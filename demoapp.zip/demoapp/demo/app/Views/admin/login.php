<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Demo - Debraj Acharya</title>

  <!-- Favicons -->
  <link href="<?php echo base_url('public/img/favicon.png'); ?>" rel="icon">
  <link href="<?php echo base_url('public/img/apple-touch-icon.png'); ?>" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url('public/lib/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo base_url('public/lib/font-awesome/css/font-awesome.css'); ?>" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="<?php echo base_url('public/css/style.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('public/css/style-responsive.css'); ?>" rel="stylesheet">
  
  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
   <script src='https://www.google.com/recaptcha/api.js'></script>
   
   <style>
       @import url('//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
 
.isa_info, .isa_success, .isa_warning, .isa_error {
margin: 10px 0px;
padding:12px;
 
}
.isa_info {
    color: #00529B;
    background-color: #BDE5F8;
}
.isa_success {
    color: #4F8A10;
    background-color: #DFF2BF;
}
.isa_warning {
    color: #9F6000;
    background-color: #FEEFB3;
}
.isa_error {
    color: #D8000C;
    background-color: #FFD2D2;
}
.isa_info i, .isa_success i, .isa_warning i, .isa_error i {
    margin:10px 22px;
    font-size:2em;
    vertical-align:middle;
}
   </style>
   
</head>

<body>
  <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
  <div id="login-page">
    <div class="container">
       
      <form class="form-login" action="<?php echo base_url('admin/login') ?>" method="post" id="loginform" autocomplete="off">
          <?php 
          $validation = \config\services::validation(); 
          if($validation->listErrors()) { ?>
          <div class="isa_error">
     <i class="fa fa-warning"></i>
     <?php echo $validation->listErrors(); ?>
      
</div><?php } if(session()->getFlashdata("message")!='') { ?>
<div class="isa_error">
     <i class="fa fa-warning"></i>
    <?php echo session()->getFlashdata("message"); ?>
      
</div><?php } ?>
 
        <h2 class="form-login-heading">Sign in now</h2>
        <div class="login-wrap">
          <input type="text" class="form-control" placeholder="User ID" autofocus name="username" id="username">
          
          <br>
          <input type="password" class="form-control" placeholder="Password" name="password" id="password">
         
      <!--    <label class="checkbox">
            <input type="checkbox" value="remember-me"> Remember me
            <span class="pull-right">
            <a data-toggle="modal" href="login.html#myModal"> Forgot Password?</a>
            </span>
            </label> --><br/><br/>
            <div class="g-recaptcha" data-sitekey="6LeZwXgaAAAAAKHIMyp1W-7kjVMKu2X7wlfRuz9-"></div>       
          <button class="btn btn-theme btn-block" href="index.html" type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
          <hr>
       
        </div>
        <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />

      </form>
    </div>
  </div>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo base_url('public/lib/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('public/lib/bootstrap/js/bootstrap.min.js'); ?>"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="<?php echo base_url('public/lib/jquery.backstretch.min.js'); ?>"></script>
  <script>
    $.backstretch("<?php echo base_url('public/lib/img/login-bg.jpg'); ?>", {
      speed: 500
    });
  </script>
</body>

</html>
