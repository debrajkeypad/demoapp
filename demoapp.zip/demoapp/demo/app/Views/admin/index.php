<?php echo $this->include('admin/common/header'); ?>

<body>
  <section id="container">
      
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>DEMO<span>&nbsp;APP</span></b></a>
      <!--logo end-->
     
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" onclick="javascript: doLogout();" href="#">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
         
         
          <li class="mt">
            <a class="active" href="<?php echo base_url('admin/dashboard') ?>">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-9 main-chart" style="width: 100%!important;">
            <!--CUSTOM CHART START -->
            <div class="border-head">
              <h3><strong>COVID-19 UPDATED STATISTICAL CHART</strong><div style="float: right;">Last Updated on : <?php echo @date('l, j F Y H:i:s', ($covid_data['updated'] / 1000)); ?></div></h3>
              
            </div>
            <div class="custom-bar-chart">
             
              <div class="bar">
                <div class="title" style="top:300px;">TOTAL <?php echo number_format($covid_data['cases']); ?></div>
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['cases']); ?>" data-toggle="tooltip" data-placement="top">100%</div>
              </div>
              <div class="bar ">
                <div class="title" style="top:300px;">DEATHS <?php echo number_format($covid_data['deaths']); ?></div>
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['deaths']); ?>" data-toggle="tooltip" data-placement="top">10%</div>
               
              </div>
              <div class="bar ">
                <div class="title" style="top:300px;">RECOVERED <?php echo number_format($covid_data['recovered']); ?></div>
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['recovered']); ?>" data-toggle="tooltip" data-placement="top">80%</div>
              </div>
              <div class="bar ">
                <div class="title" style="top:300px;">ACTIVE <?php echo number_format($covid_data['active']); ?></div>
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['active']); ?>" data-toggle="tooltip" data-placement="top">20%</div>
              </div>
              <div class="bar">
                <div class="title"  style="top:300px;">CRITICAL <?php echo number_format($covid_data['critical']); ?></div>
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['critical']); ?>" data-toggle="tooltip" data-placement="top">2%</div>
              </div>
                 <div class="bar">
                <div class="title" style="top:300px;">TESTS <?php echo number_format($covid_data['tests']); ?></div>
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['tests']); ?>" data-toggle="tooltip" data-placement="top">100%</div>
              </div>
                 <div class="bar">
                <div class="title" style="top:300px;">COUNTRIES <?php echo number_format($covid_data['affectedCountries']); ?></div>
                
                <div class="value tooltips" data-original-title="<?php echo number_format($covid_data['affectedCountries']); ?>" data-toggle="tooltip" data-placement="top">94%</div>
              </div>
              
            </div>
            <div style="height:11px;">&nbsp;</div>
            <!--custom chart end-->
            <div class="row mt">
              <!-- SERVER STATUS PANELS -->
           <div class="col-md-4 col-sm-4 mb">
                <div class="grey-panel pn donut-chart">
                  <div class="grey-header">
                    <h5 style='color: #000!important;'>TODAY CASES</h5>
                  </div>
                  <canvas id="serverstatus01" height="120" width="120"></canvas>
                  <script>
                    var doughnutData = [{
                        value: 100,
                        color: "blue"
                      },
                      {
                        value: 0,
                        color: "#fdfdfd"
                      }
                    ];
                    var myDoughnut = new Chart(document.getElementById("serverstatus01").getContext("2d")).Doughnut(doughnutData);
                  </script>
                  <div class="row">
                    <div class="col-sm-6 col-xs-6 goleft">
                      <h2><?php echo number_format($covid_data['todayCases']); ?></h2>
                    </div>
                    <div class="col-sm-6 col-xs-6">
                      
                    </div>
                  </div>
                </div>
                <!-- /grey-panel -->
              </div>
                  <div class="col-md-4 col-sm-4 mb">
                <div class="grey-panel pn donut-chart">
                  <div class="grey-header">
                    <h5 style='color: #000!important;'>TODAY DEATHS</h5>
                  </div>
                  <canvas id="serverstatus02" height="120" width="120"></canvas>
                  <script>
                    var doughnutData = [{
                        value: 100,
                        color: "red"
                      },
                      {
                        value: 0,
                        color: "#fdfdfd"
                      }
                    ];
                    var myDoughnut = new Chart(document.getElementById("serverstatus02").getContext("2d")).Doughnut(doughnutData);
                  </script>
                  <div class="row">
                    <div class="col-sm-6 col-xs-6 goleft">
                      <h2><?php echo number_format($covid_data['todayDeaths']); ?></h2>
                    </div>
                  </div>
                </div>
                <!-- /grey-panel -->
              </div>
                  <div class="col-md-4 col-sm-4 mb">
                <div class="grey-panel pn donut-chart">
                  <div class="grey-header">
                    <h5 style='color: #000!important;'>TODAY RECOVERED</h5>
                  </div>
                  <canvas id="serverstatus03" height="120" width="120"></canvas>
                  <script>
                    var doughnutData = [{
                        value: 100,
                        color: "green"
                      },
                      {
                        value: 0,
                        color: "#fdfdfd"
                      }
                    ];
                    var myDoughnut = new Chart(document.getElementById("serverstatus03").getContext("2d")).Doughnut(doughnutData);
                  </script>
                  <div class="row">
                     <div class="col-sm-6 col-xs-6 goleft">
                      <h2><?php echo number_format($covid_data['todayRecovered']); ?></h2>
                    </div>
                  </div>
                </div>
                <!-- /grey-panel -->
              </div>
              
              <!-- /col-md-4-->
             
              <!-- /col-md-4 -->
           
              <!-- /col-md-4 -->
            </div>
            <!-- /row -->
          
            <!-- /row -->
          </div>
          <!-- /col-lg-9 END SECTION MIDDLE -->
          <!-- **********************************************************************************************************************************************************co
              RIGHT SIDEBAR CONTENT
              *********************************************************************************************************************************************************** -->
     
          <!-- /col-lg-3 -->
        </div>
        <!-- /row -->
      </section>
    </section>
    <!--main content end-->
    <!--footer start-->
   <?= $this->include('admin/common/footer') ?>

</body>

</html>
