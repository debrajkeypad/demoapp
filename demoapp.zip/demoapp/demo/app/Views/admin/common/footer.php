<footer class="site-footer">
      <div class="text-center">
        <p>
          Copyright  &copy; <?php echo @date('Y'); ?>&nbsp;<strong>Demo APP</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Created & Managed by Debraj Acharya
        </div>
        <a href="#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="<?php echo base_url('public/lib/jquery/jquery.min.js'); ?>"></script>

  <script src="<?php echo base_url('public/lib/bootstrap/js/bootstrap.min.js'); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo base_url('public/lib/jquery.dcjqaccordion.2.7.js'); ?>"></script>
  <script src="<?php echo base_url('public/lib/jquery.scrollTo.min.js'); ?>"></script>
  <script src="<?php echo base_url('public/lib/jquery.nicescroll.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('public/lib/jquery.sparkline.js'); ?>"></script>
  <!--common script for all pages-->
  <script src="<?php echo base_url('public/lib/common-scripts.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo base_url('public/lib/gritter/js/jquery.gritter.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo base_url('public/lib/gritter-conf.js'); ?>"></script>
  <!--script for this page-->
  <script src="<?php echo base_url('public/lib/sparkline-chart.js'); ?>"></script>
  <script src="<?php echo base_url('public/lib/zabuto_calendar.js'); ?>"></script>
 