<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Demo App , Dashboard , Admin Panel , Backend Panel">
  <title>Demo APP | Admin Panel</title>

  <!-- Favicons -->
  <link href="<?php echo base_url('public/img/favicon.png'); ?>" rel="icon">
  <link href="<?php echo base_url('public/img/apple-touch-icon.png'); ?>" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo base_url('public/lib/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo base_url('public/lib/font-awesome/css/font-awesome.css'); ?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('public/css/zabuto_calendar.css'); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('public/lib/gritter/css/jquery.gritter.css'); ?>" />
  <!-- Custom styles for this template -->
  <link href="<?php echo base_url('public/css/style.css'); ?>" rel="stylesheet">
  <link href="<?php echo base_url('public/css/style-responsive.css'); ?>" rel="stylesheet">
  <script src="<?php echo base_url('public/lib/chart-master/Chart.js'); ?>"></script>

  <!-- =======================================================
    Template Name: Demo
    Template URL: https://templatemag.com/Demo-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
  <script>
      function doLogout()
      {
          let p =  confirm('Are you sure you want to logout?');
          if(p==true)
          {
              window.location.href="<?php echo base_url('admin/logout') ?>";
          }
          else
          {
              return false;
          }
      }
  </script>
</head>