<?php namespace App\Models;
use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
 
class AdminModel extends Model
{
    protected $table = 'Users';
 
    protected $allowedFields = ['username','password','first_name','last_name','address','email', 'mobile'];
}
?>