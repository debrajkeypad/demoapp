<?php 
namespace App\Models;
use CodeIgniter\Database\ConnectionInterface;
use CodeIgniter\Model;
 
class SettingsModel extends Model
{
    protected $table = 'settings';
 
    protected $allowedFields = ['recaptcha_secret_key','maintenence_mode'];
}
?>